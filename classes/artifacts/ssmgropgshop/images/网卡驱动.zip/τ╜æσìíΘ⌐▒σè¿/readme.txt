(C)Copyright 2000-2006 Attansic(R).
All rights reserved.
*************************************************************************
*																																				*
* Readme.txt created 08-FEB-2006																				*
*																																				*	
* Readme File for L1 setup package																			*
*																																				*
* Supporting: Attansic L1 Gigabit Ethernet Controller										*
*																																				*	
* Operation Systems:																										*	
* Windows 2000, Windows XP, Windows Server 2003,				                *
*	Windows XP x64, Windows Server 2003 x64                               *
*																																			  *		
*************************************************************************

This file contains
 1  Overview
 2  Installation
 3  Uninstallation
 		3.1 Driver Removal
 		3.2 Utility Removal

*************************************************************************


1  Overview
***********


The driver installation package contains the Attansic
L1 Gigabit Ethernet Controller Driver and Utility.

This README file explains how to install the driver and 
utility installation package on a machine running one 
of the following operation systems:

Windows 2000, Windows XP, Windows Server 2003, Windows XP x64, Windows Server 2003 x64


2  Installation
***************


Windows operation system will detect the adapter automatically. 
Cancel all dialogue boxes that operation system attempts to 
install the driver automatically.  


NOTE: User has to log in with administrative rights to 
			be able to install driver.

To install the driver, proceed as follows:

1. Execute the setup file "Setup.exe".
2. Follow the instructions displayed during the 
   installation procedure.


3  Uninstallation
*****************



In order to uninstall the driver or utility the following
procedure should be taken.

3.1  Driver Removal
===================

1. Go to "Start" > "Control Panel" > "Add or Remove Programs".
2. Find "Attansic L1 Gigabit Ethernet Driver", select it and click the "Remove" button.


3.2  Utility Removal
====================

1. Go to "Start" > "Control Panel" > "Add or Remove Programs".
2. Find "Attansic Ethernet Utility", select it and click the "Remove" button. 
3. Select "Remove" and click "Next" button.
4. Click "Finish" to complete the uninstallation.


For further information please contact our support.


*** End of Readme File ***


